import React from 'react';

export const Header = () => {
  return (
    <header className="bg-gray-800 text-white py-4">
      <div className="container mx-auto flex flex-col items-center">
        <h1 className="text-4xl font-bold">Prithvika</h1>
        <h2>Student</h2>
        <br />
        <nav>
          <ul className="flex space-x-4">
            <li>
              <a href="/" className="hover:text-gray-300">
                Home
              </a>
            </li>
            <li>
              <a href="/About" className="hover:text-gray-300">
                About
              </a>
            </li>
            
            <li>
              <a href="/Projects" className="hover:text-gray-300">
                Projects
              </a>
            </li>
            <li>
              <a href="/PersonalDetails" className="hover:text-gray-300">
                PersonalDetails
              </a>
            </li>
            <li>
              <a href="/Contact" className="hover:text-gray-300">
                Contact
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};
