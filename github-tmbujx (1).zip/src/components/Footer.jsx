import React from 'react';

export const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-4" style={{  bottom: 0, width: '100%' }}>
      <div className="container mx-auto text-center">
        <p>&copy; 2023 Prithvika V. All rights reserved.</p>
      </div>
    </footer>
  );
};
