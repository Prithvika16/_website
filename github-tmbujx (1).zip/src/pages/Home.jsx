import React from 'react';

export function Home() {
  const boxStyle = {
    backgroundColor: 'white',
    border: '1px solid purple',
    borderRadius: '19px',
    padding: '25px',
    marginBottom: '16px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  };
  const containerStyle = {
    backgroundImage: "url('https://drive.google.com/uc?export=view&id=1CtzA84SmL_0l-4Mo5Ua4KvJYqd4hGnR7')",
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    padding: '100px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'column',
  };
  const imageStyle = {
    width: '150px',
    height: '200px',
    display: 'block',
    padding: '5px',
    borderRadius: '65px',
    margin: '0 auto', // Center align horizontally
  };

  return (
    <div className="home-container" style={containerStyle}>
      <div style={boxStyle}>
        <h1 className="text-3xl text-purple-800 font-bold p-2">Hello and Welcome!</h1>
        <p className="text-lg text-gray-700 leading-relaxed" align="center">
          Hello! My name is Prithvika, and I'm delighted to welcome you to my student website. This website serves as a platform for me to showcase my academic journey, projects, and interests. Please feel free to explore my portfolio, browse through my projects, and get to know me better. Thank you for visiting!
        </p>
        <img src="https://drive.google.com/uc?export=view&id=1qqyBj_a-p7FaPrODUnweGU036bCHfUxI" alt="My Image" style={imageStyle} />
      </div>
    </div>
  );
}
