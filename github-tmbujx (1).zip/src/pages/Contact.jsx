export  function Contact() {
  const boxStyle = {
    backgroundColor: 'white',
    border: '1px solid purple',
    borderRadius: '19px',
    padding: '25px',
    marginBottom: '16px',
    display: 'flex',
    flexDirection: 'column',
    
  };
  const containerStyle = {
    backgroundImage: "url('https://drive.google.com/uc?export=view&id=1CtzA84SmL_0l-4Mo5Ua4KvJYqd4hGnR7')",
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    padding: '100px',
    display: 'flex',
    justifyContent: 'center',
    flexDirection: 'column',
  };
  const headingStyle = {
    color: 'purple',
    fontSize: '2rem',
    fontWeight: 'bold',
    marginBottom: '1rem',
  };
    
      return (
        <section className="py-8">
          <div style={containerStyle}>
          <div className="container mx-auto" style={boxStyle}>
            
            <h2 className="text-2xl font-bold mb-4" style={headingStyle}>Contact Me</h2>
            <form className="max-w-md mx-auto" id="myForm">
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="name">Name</label>
                <input className="appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="name" type="text" placeholder="Enter your name" />
              </div>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">Email</label>
                <input className="appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="email" type="email" placeholder="Enter your email" />
              </div>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="message">Message</label>
                <textarea className="appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="message" placeholder="Enter your message"></textarea>
              </div>
              <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="submit">Submit</button>
            </form>
          </div>
          </div>
        </section>
      );
      
    }
    
    function SkillSet() {
      return (
        <section className="py-8 bg-gray-100">
          <div className="container mx-auto">
            <h2 className="text-2xl font-bold mb-4">Skill Set</h2>
            <ul className="grid grid-cols-2 gap-4">
              <li className="bg-white p-4 shadow">
                <h3 className="text-xl font-bold mb-2">Python</h3>
                <p className="text-gray-700">Proficient</p>
              </li>
              <li className="bg-white p-4 shadow">
                <h3 className="text-xl font-bold mb-2">C++</h3>
                <p className="text-gray-700">Intermediate</p>
              </li>
            </ul>
          </div>
        </section>
      );
      
    }
    
    
    