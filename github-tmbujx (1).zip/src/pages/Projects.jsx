import React from 'react';

export function Projects() {
  const boxStyle = {
    backgroundColor: 'white',
    border: '1px solid purple',
    borderRadius: '19px',
    padding: '25px',
    marginBottom: '16px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'left',
    textAlign: 'left',
  };

  const containerStyle = {
    backgroundImage: "url('https://drive.google.com/uc?export=view&id=1CtzA84SmL_0l-4Mo5Ua4KvJYqd4hGnR7')",
    backgroundSize: 'cover',
    backgroundPosition: 'left',
    padding: '100px',
    display: 'flex',
    justifyContent: 'left',
    flexDirection: 'column',
  };

  const iconContainerStyle = {
    display: 'flex',
    alignItems: 'left',
  };


  return (
    <div className="container mx-auto p-8" style={containerStyle}>
      <div style={boxStyle}>
        <h3 className="text-3xl text-purple-800 font-bold p-2">Projects</h3>

        <div>
          
          <p>
          <h4 className="text-lg text-blue-400 font-bold">
  <a href="https://stackblitz.com/edit/github-tmbujx?file=src%2Fpages%2FProjects.jsx"
    style={{ textDecoration: 'underline' }}
  >
    Personalised Website link
  </a>
</h4>

            This website is tailored by me using HTML,CSS, ReactJs to showcase my resume to employers. It  includes features such as customized layouts, personalized content, and interactive elements designed to enhance the user experience.<br/><br/>
          </p>
        </div>

        <div>
        <p>
          <h4 className="text-lg text-blue-400 font-bold"><a href="https://colab.research.google.com/drive/1u8-Hk5g2rakBHi9eKR8gjozljASuD4XQ?usp=sharing" style={{ textDecoration: 'underline' }}>
            Machine Learning Modeling : Colab Notebook link
            </a></h4>
            This machine learning model for heart disease prediction in Python involves using various algorithms and techniques to build a predictive model that can accurately classify whether a person has heart disease or not based on a set of input features. The interface I used is 'Streamlit', to deploy my model and the image below shows the screenshot of my interface
          </p>
        </div>

        <img
          src="https://drive.google.com/uc?id=1LWt4RMcOzl4SHIBDHHuyZQ79OJ8GrBQ8"
          alt="Project Images"
        />
      </div>
    </div>
  );
}
