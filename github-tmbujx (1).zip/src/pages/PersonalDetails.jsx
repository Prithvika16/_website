import React from 'react';

export function PersonalDetails() {
  const boxStyle = {
    backgroundColor: 'white',
    border: '1px solid purple',
    borderRadius: '19px',
    padding: '25px',
    marginBottom: '16px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'left',
    textAlign: 'left',
  };

  const containerStyle = {
    backgroundImage: "url('https://drive.google.com/uc?export=view&id=1CtzA84SmL_0l-4Mo5Ua4KvJYqd4hGnR7')",
    backgroundSize: 'cover',
    backgroundPosition: 'left',
    padding: '100px',
    display: 'flex',
    justifyContent: 'left',
    flexDirection: 'column',
  };

  const iconContainerStyle = {
    display: 'flex',
    alignItems: 'center',
  };

  const githubIconStyle = {
    backgroundImage: "url('https://drive.google.com/uc?export=view&id=165Wz3Do6uFMT0toPMe32pD2dXvJftmlI')",
    backgroundSize: 'contain',
    backgroundRepeat: 'no-repeat',
    backgroundPosition: 'left center',
    height: '64px',
    width: '64px',
    marginRight: '10px',
    display: 'inline-block',
  };

  const linkedinIconStyle = {
    backgroundImage: "url('https://drive.google.com/uc?export=view&id=1Jr0E4x7kXnpqKAesJ-m7Ic7hpFwX_iio')",
    backgroundSize: 'contain',
    backgroundRepeat: 'no-repeat',
    backgroundPosition: 'left center',
    height: '64px',
    width: '64px',
    marginRight: '10px',
    display: 'inline-block',
  };
  const tabSpace = '\u00A0\u00A0\u00A0\u00A0'; // Four non-breaking spaces for a tab

  return (
    <div className="container mx-auto p-8" style={containerStyle}>
      <h1 className="text-3xl text-purple-800 font-bold p-2" align='center'>Personal Details</h1>
      <div style={boxStyle}>
        <p className="text-lg text-grey-700 leading-relaxed">
          <strong>Full name:</strong> Prithvika Venkateswaran
        </p>
      </div>
      <div style={boxStyle}>
        <p className="text-lg text-gray-700 leading-relaxed">
          <strong>Date of Birth:</strong> 16/03/2002
        </p>
        <p className="text-lg text-gray-700 leading-relaxed">
          <strong>Email:</strong> prithvika163202@gmail.com
        </p>
        <p className="text-lg text-gray-700 leading-relaxed">
          <strong>Phone number:</strong> 9940651781
        </p>
        <p className="text-lg text-gray-700 leading-relaxed">
          <strong>Address:</strong> C2 Ceebros Srinivas Apts; 8/84 Bazullah Road (T.Nagar), Chennai-600017
        </p>
      </div>

      <div style={boxStyle}>
        <p className="text-lg text-gray-700 leading-relaxed">
          <strong>Job positions looking for:</strong> Software developer, Information Technology consultant
        </p>
        <p className="text-lg text-gray-700 leading-relaxed">
          <strong>Willing to relocate for work:</strong> <span>&#10003;</span>
        </p>
        <p className="text-lg text-gray-700 leading-relaxed">
          <strong>Language proficiencies:</strong> Fluent in English, Tamil (Hindi - intermediate)
        </p><br/>

        <div style={iconContainerStyle}>
          <p className="text-lg text-gray-700 leading-relaxed">
            <strong>Social media handles:</strong> {tabSpace}
          </p>
          <a href="https://github.com/prithvika163202">
            <i className="fab fa-github" style={githubIconStyle}></i>
          </a>
          <a href="www.linkedin.com/in/prithvika-venkateswaran-a91281281">
            <i className="fab fa-linkedin" style={linkedinIconStyle}></i>
          </a>
        </div>
      </div>
    </div>
  );
}
