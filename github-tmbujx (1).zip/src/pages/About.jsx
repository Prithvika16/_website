export function About() {
  const boxStyle = {
    backgroundColor: 'white',
    border: '1px solid purple',
    borderRadius: '19px',
    padding: '25px',
    marginBottom: '16px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  };

  const containerStyle = {
    backgroundImage: "url('https://drive.google.com/uc?export=view&id=1CtzA84SmL_0l-4Mo5Ua4KvJYqd4hGnR7')",
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    padding: '100px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'column',
  };

  const headingStyle = {
    color: 'purple',
    fontSize: '2rem',
    fontWeight: 'bold',
    marginBottom: '1rem',
  };

  const highlightStyle = {
    backgroundColor: 'yellow',
    fontWeight: 'bold',
  };
  const listItemStyle = {
    listStyleType: 'none',
    position: 'relative',
    paddingLeft: '1em',
  };

  const bulletStyle = {
    position: 'absolute',
    left: '0.25em',
    top: '0.05em',
    color: 'purple',
    fontSize: '1em',
  };
  const skillsImageStyle = {
    maxWidth: '100%',
    marginBottom: '1rem',
  };
  const tabSpace = '\u00A0\u00A0\u00A0\u00A0'; // Four non-breaking spaces for a tab


  return (
    <div className="container mx-auto p-8" style={containerStyle}>
      <div style={boxStyle}>
        <h2 style={headingStyle}>About Me</h2>
        <p className="text-lg text-darkblue-900 leading-relaxed">
          I am an engineering student specializing in Information and Communication Technology. With a strong passion
          for technology, I am constantly seeking opportunities to expand my knowledge and skills in areas such as
          software development, data analysis, and network security.
          <br />
          Through my academic coursework, I have gained fundamental knowledge in programming languages, database
          management, and telecommunications.
          <br />
          With a collaborative mindset and effective communication skills, I am eager to contribute to innovative
          projects and work in a dynamic team environment.
          <br />
          <br />
        </p>
        <br />

        <hr style={{ borderBottom: '2px solid blue', width: '50%', margin: '20px auto' }} />
      
        <h2 style={headingStyle}>Education</h2>

        <p className="text-lg text-darkblue-900 leading-relaxed">
        <ul style={{ paddingLeft: '0', marginTop: '0' }}>
          <li style={listItemStyle}>
          <span style={bulletStyle}>&#10148;</span> {tabSpace}Padma Seshadri Bala Bhavan Senior Secondary School <br/>2018: Central Board All India Secondary School
          Examination (Class 10) -<span style={highlightStyle}> 94.6% </span>
          </li>
          </ul>
          <br />
          <br />
          <ul style={{ paddingLeft: '0', marginTop: '0' }}>
          <li style={listItemStyle}>
          <span style={bulletStyle}>&#10148;</span> {tabSpace}Padma Seshadri Bala Bhavan Senior Secondary School <br/>2020: Central Board Senior Secondary School Certificate Examination <br />
          (Class 12 - Electives: Mathematics, Physics, Chemistry, Biology) -{' '}
          <span style={highlightStyle}>91.8% </span>
          </li>
          </ul>
          <br />
          <br />
          <ul style={{ paddingLeft: '0', marginTop: '0' }}>
          <li style={listItemStyle}>
          <span style={bulletStyle}>&#10148;</span> {tabSpace}SASTRA DEEMED TO BE UNIVERSITY <br/>2020-2024: Bachelor of Technology (Information and Communication) <br />
          <br />
          </li>
          </ul>
        </p>
        <br />
        <hr style={{ borderBottom: '2px solid blue', width: '50%', margin: '20px auto' }} />
        <h2 style={headingStyle}>Skills</h2>

        <p>
        <img src="https://drive.google.com/uc?export=view&id=179_d-TBb_ujnsjJRWW-NDKHbXLB5lU9m" alt="Skills" style={skillsImageStyle} />
        </p>
        <br />
      </div>
    </div>
  );
}
