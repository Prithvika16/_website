import { Outlet, createBrowserRouter } from 'react-router-dom';


import { About } from './pages/About';
import { Home } from './pages/Home';

import { Projects } from './pages/Projects';
import { PersonalDetails } from './pages/PersonalDetails';
import { Contact } from './pages/Contact';

import { Header } from './components/NavBar';
import { Footer } from './components/Footer';

const routes = [
  {
    path: '/',
    element: <Home />,
  },
  {
    path: 'About',
    element: <About />,
  },
  
  {
    path: 'Projects',
    element: <Projects />,
  },
  {
    path: 'PersonalDetails',
    element: <PersonalDetails />,
  },
  {
    path: 'contact',
    element: <Contact />,
  },
  
  
];

//   function NavBarWrapper() {
//     return (<>
//     <NavBar />
//     <Outlet />
//     </>)
//   }

//   const routes = [
//     {
//         path: "/",
//         element: <NavBarWrapper/>,
//         children:[
//              {
//                  path: "/", // yes, again
//                  element: <Home/>
//              },
//              {
//                  path: "/about",
//                  element: <About />
//              },
//         ]
//     }
// ];

export const router = createBrowserRouter(routes);
