import { RouterProvider } from 'react-router-dom';
import { router } from './Router';
import { Header } from './components/NavBar';
import { Home } from './pages/Home';
import { Contact } from './pages/Contact';
import { Footer } from './components/Footer';


export default function App() {
  return (
    <>
      <Header />
      <RouterProvider router={router} />

      <Footer />
     
      
    </>
    
  );
}
