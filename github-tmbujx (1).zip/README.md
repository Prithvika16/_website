# react-vite-starter
Starter project for learning -  a basic react vite app
